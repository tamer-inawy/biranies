#!bin/bash

# This script is a just to facilitate the clone process.

GITHUB_USER=$1
GITHUB_PASSWD=$2
ISUPPLY_BRANCH=$3

# Cloning the repository
cd /opt
git clone https://$GITHUB_USER:$GITHUB_PASSWD@github.com/trilogy-group/avolin-tradebeam-isupply.git
cd avolin-tradebeam-isupply
# Changing to the given branch
git checkout $ISUPPLY_BRANCH
